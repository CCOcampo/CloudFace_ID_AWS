import boto3
import json

s3 = boto3.client('s3')
rekognition = boto3.client('rekognition', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
employeeTable = dynamodb.Table('employee')
bucketName = 'visitor-images-storage-rk1'

def lambda_handler(event, context):
    try:
        # Validar parámetros de consulta
        query_params = event.get('queryStringParameters', {})
        objectKey = query_params.get('objectKey') if query_params else None

        if not objectKey:
            return buildResponse(400, {'Message': 'Parámetro objectKey faltante'})

        # Validar extensión del archivo
        if not objectKey.lower().endswith(('.jpg', '.jpeg', '.png')):
            return buildResponse(400, {'Message': 'Formato de imagen no válido'})

        # Obtener imagen desde S3
        try:
            image_bytes = s3.get_object(Bucket=bucketName, Key=objectKey)['Body'].read()
        except Exception as e:
            return buildResponse(404, {'Message': 'Imagen no encontrada en S3'})

        # Buscar coincidencias en Rekognition
        response = rekognition.search_faces_by_image(
            CollectionId='employees',
            Image={'Bytes': image_bytes}
        )

        # Procesar resultados
        for match in response.get('FaceMatches', []):
            face_id = match['Face']['FaceId']
            face_data = employeeTable.get_item(Key={'rekognitionId': face_id}).get('Item')

            if face_data:
                return buildResponse(200, {
                    'Message': 'Success',
                    'firstName': face_data['firstName'],
                    'lastName': face_data['lastName']
                })

        return buildResponse(404, {'Message': 'Empleado no reconocido'})

    except Exception as e:
        print(f"Error: {str(e)}")
        return buildResponse(500, {'Message': 'Error interno del servidor'})

def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }
    if body:
        response['body'] = json.dumps(body)
    return response
